﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WebApplication4.Models;

namespace WebApplication4.Controllers
{
    public class ProductsController : Controller
    {
        private TaskEntities db = new TaskEntities();
        // GET: Products
        public ActionResult Index()
        {
            return View(db.Products.ToList()); ;
        }

        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(Login l)
        {
            using (TaskEntities db = new TaskEntities())
            {
                var r = db.UserMasters.Where(x => x.User_name == l.User_Name && x.password == l.Password).FirstOrDefault();
                if (r != null)
                {
                    return RedirectToAction("Index", "Products");
                }
                else
                {
                    TempData["msg"] = "Incorrect userid/password";

                }
            }
            return View();

        }
        public ActionResult Insert()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Insert(Product p)
        {
            using (TaskEntities db = new TaskEntities())
            {
                db.Products.Add(p);
                int r = db.SaveChanges();
                if (r > 0)
                {
                    ViewBag.msg = "Inserted Successfully";
                }
                else
                {
                    ViewBag.msg = "failed to Insert";
                }
            }
            return View(p);
        }
        public ActionResult update(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Product p = db.Products.Find(id);
            if (p == null)
            {
                return HttpNotFound();
            }
            return View(p);
        }

        [HttpPost]

        public ActionResult update(Product p)
        {
            if (ModelState.IsValid)
            {
                db.Entry(p).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index", "Products");
            }
            return View(p);
        }
    
    public ActionResult Delete(int id)

    {
        using (TaskEntities db = new TaskEntities())
        {
            db.Products.Remove(db.Products.Where(x => x.id == id).FirstOrDefault());
            
                db.SaveChanges();
                return RedirectToAction("Index", "Products");

            }
        return View();
    }
    }
}